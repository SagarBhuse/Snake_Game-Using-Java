# this game is made using java
# in order to run the game run java file "SnakeGame.java" in the terminal
